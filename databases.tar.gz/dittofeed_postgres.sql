--
-- PostgreSQL database dump
--

\restrict Ug1i0FmdY3S9z3a4GO6jiBHd9rigIwZvXQQekX1suWnPTYIX4SaVo9ealmbMdC4

-- Dumped from database version 15.15 (Debian 15.15-1.pgdg13+1)
-- Dumped by pg_dump version 15.15 (Debian 15.15-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: drizzle; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA drizzle;


ALTER SCHEMA drizzle OWNER TO postgres;

--
-- Name: ComputedPropertyType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ComputedPropertyType" AS ENUM (
    'Segment',
    'UserProperty'
);


ALTER TYPE public."ComputedPropertyType" OWNER TO postgres;

--
-- Name: DBBroadcastStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."DBBroadcastStatus" AS ENUM (
    'NotStarted',
    'InProgress',
    'Triggered'
);


ALTER TYPE public."DBBroadcastStatus" OWNER TO postgres;

--
-- Name: DBChannelType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."DBChannelType" AS ENUM (
    'Email',
    'MobilePush',
    'Sms',
    'Webhook'
);


ALTER TYPE public."DBChannelType" OWNER TO postgres;

--
-- Name: DBCompletionStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."DBCompletionStatus" AS ENUM (
    'NotStarted',
    'InProgress',
    'Successful',
    'Failed'
);


ALTER TYPE public."DBCompletionStatus" OWNER TO postgres;

--
-- Name: DBResourceType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."DBResourceType" AS ENUM (
    'Declarative',
    'Internal'
);


ALTER TYPE public."DBResourceType" OWNER TO postgres;

--
-- Name: DBRoleType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."DBRoleType" AS ENUM (
    'Admin',
    'WorkspaceManager',
    'Author',
    'Viewer'
);


ALTER TYPE public."DBRoleType" OWNER TO postgres;

--
-- Name: DBSubscriptionGroupType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."DBSubscriptionGroupType" AS ENUM (
    'OptIn',
    'OptOut'
);


ALTER TYPE public."DBSubscriptionGroupType" OWNER TO postgres;

--
-- Name: JourneyStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."JourneyStatus" AS ENUM (
    'NotStarted',
    'Running',
    'Paused',
    'Broadcast'
);


ALTER TYPE public."JourneyStatus" OWNER TO postgres;

--
-- Name: SegmentStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SegmentStatus" AS ENUM (
    'NotStarted',
    'Running',
    'Paused'
);


ALTER TYPE public."SegmentStatus" OWNER TO postgres;

--
-- Name: WorkspaceStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."WorkspaceStatus" AS ENUM (
    'Active',
    'Tombstoned',
    'Paused'
);


ALTER TYPE public."WorkspaceStatus" OWNER TO postgres;

--
-- Name: WorkspaceType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."WorkspaceType" AS ENUM (
    'Root',
    'Child',
    'Parent'
);


ALTER TYPE public."WorkspaceType" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: __drizzle_migrations; Type: TABLE; Schema: drizzle; Owner: postgres
--

CREATE TABLE drizzle.__drizzle_migrations (
    id integer NOT NULL,
    hash text NOT NULL,
    created_at bigint
);


ALTER TABLE drizzle.__drizzle_migrations OWNER TO postgres;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE; Schema: drizzle; Owner: postgres
--

CREATE SEQUENCE drizzle.__drizzle_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE drizzle.__drizzle_migrations_id_seq OWNER TO postgres;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: drizzle; Owner: postgres
--

ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNED BY drizzle.__drizzle_migrations.id;


--
-- Name: AdminApiKey; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AdminApiKey" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "workspaceId" uuid NOT NULL,
    name text NOT NULL,
    "secretId" uuid NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."AdminApiKey" OWNER TO postgres;

--
-- Name: Broadcast; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Broadcast" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "workspaceId" uuid NOT NULL,
    "segmentId" uuid,
    name text NOT NULL,
    "triggeredAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "journeyId" uuid,
    "messageTemplateId" uuid,
    status public."DBBroadcastStatus" DEFAULT 'NotStarted'::public."DBBroadcastStatus" NOT NULL
);


ALTER TABLE public."Broadcast" OWNER TO postgres;

--
-- Name: ComponentConfiguration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ComponentConfiguration" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "workspaceId" uuid NOT NULL,
    name text NOT NULL,
    definition jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."ComponentConfiguration" OWNER TO postgres;

--
-- Name: ComputedPropertyPeriod; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ComputedPropertyPeriod" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "workspaceId" uuid NOT NULL,
    type public."ComputedPropertyType" NOT NULL,
    "computedPropertyId" uuid NOT NULL,
    version text NOT NULL,
    "from" timestamp(3) without time zone,
    "to" timestamp(3) without time zone NOT NULL,
    step text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."ComputedPropertyPeriod" OWNER TO postgres;

--
-- Name: DefaultEmailProvider; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."DefaultEmailProvider" (
    "workspaceId" uuid NOT NULL,
    "emailProviderId" uuid NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "fromAddress" text
);


ALTER TABLE public."DefaultEmailProvider" OWNER TO postgres;

--
-- Name: DefaultSmsProvider; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."DefaultSmsProvider" (
    "workspaceId" uuid NOT NULL,
    "smsProviderId" uuid NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."DefaultSmsProvider" OWNER TO postgres;

--
-- Name: EmailProvider; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EmailProvider" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "workspaceId" uuid NOT NULL,
    type text NOT NULL,
    "apiKey" text,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "secretId" uuid
);


ALTER TABLE public."EmailProvider" OWNER TO postgres;

--
-- Name: EmailTemplate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EmailTemplate" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "workspaceId" uuid NOT NULL,
    name text NOT NULL,
    "from" text NOT NULL,
    subject text NOT NULL,
    body text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "replyTo" text
);


ALTER TABLE public."EmailTemplate" OWNER TO postgres;

--
-- Name: Feature; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Feature" (
    "workspaceId" uuid NOT NULL,
    name text NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    config jsonb
);


ALTER TABLE public."Feature" OWNER TO postgres;

--
-- Name: Integration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Integration" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "workspaceId" uuid NOT NULL,
    name text NOT NULL,
    definition jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "definitionUpdatedAt" timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."Integration" OWNER TO postgres;

--
-- Name: Journey; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Journey" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "workspaceId" uuid NOT NULL,
    name text NOT NULL,
    status public."JourneyStatus" DEFAULT 'NotStarted'::public."JourneyStatus" NOT NULL,
    definition jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "resourceType" public."DBResourceType" DEFAULT 'Declarative'::public."DBResourceType" NOT NULL,
    "canRunMultiple" boolean DEFAULT false NOT NULL,
    draft jsonb,
    "statusUpdatedAt" timestamp(3) without time zone
);


ALTER TABLE public."Journey" OWNER TO postgres;

--
-- Name: MessageTemplate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."MessageTemplate" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "workspaceId" uuid NOT NULL,
    name text NOT NULL,
    definition jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "resourceType" public."DBResourceType" DEFAULT 'Declarative'::public."DBResourceType" NOT NULL,
    draft jsonb
);


ALTER TABLE public."MessageTemplate" OWNER TO postgres;

--
-- Name: OauthToken; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."OauthToken" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "workspaceId" uuid NOT NULL,
    name text NOT NULL,
    "refreshToken" text NOT NULL,
    "accessToken" text NOT NULL,
    "expiresIn" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."OauthToken" OWNER TO postgres;

--
-- Name: Secret; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Secret" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "workspaceId" uuid NOT NULL,
    name text NOT NULL,
    value text,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "configValue" jsonb
);


ALTER TABLE public."Secret" OWNER TO postgres;

--
-- Name: Segment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Segment" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "workspaceId" uuid NOT NULL,
    name text NOT NULL,
    definition jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "resourceType" public."DBResourceType" DEFAULT 'Declarative'::public."DBResourceType" NOT NULL,
    "subscriptionGroupId" uuid,
    status public."SegmentStatus" DEFAULT 'Running'::public."SegmentStatus" NOT NULL,
    "definitionUpdatedAt" timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."Segment" OWNER TO postgres;

--
-- Name: SegmentAssignment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SegmentAssignment" (
    "userId" text NOT NULL,
    "inSegment" boolean NOT NULL,
    "workspaceId" uuid NOT NULL,
    "segmentId" uuid NOT NULL
);


ALTER TABLE public."SegmentAssignment" OWNER TO postgres;

--
-- Name: SegmentIOConfiguration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SegmentIOConfiguration" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "workspaceId" uuid NOT NULL,
    "sharedSecret" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."SegmentIOConfiguration" OWNER TO postgres;

--
-- Name: SmsProvider; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SmsProvider" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "workspaceId" uuid NOT NULL,
    "secretId" uuid NOT NULL,
    type text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."SmsProvider" OWNER TO postgres;

--
-- Name: SubscriptionGroup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SubscriptionGroup" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "workspaceId" uuid NOT NULL,
    name text NOT NULL,
    type public."DBSubscriptionGroupType" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    channel public."DBChannelType" NOT NULL
);


ALTER TABLE public."SubscriptionGroup" OWNER TO postgres;

--
-- Name: UserJourneyEvent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."UserJourneyEvent" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "userId" text NOT NULL,
    "journeyId" uuid,
    type text NOT NULL,
    "journeyStartedAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "nodeId" text,
    "eventKey" text,
    "eventKeyName" text
);


ALTER TABLE public."UserJourneyEvent" OWNER TO postgres;

--
-- Name: UserProperty; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."UserProperty" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "workspaceId" uuid NOT NULL,
    name text NOT NULL,
    definition jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "resourceType" public."DBResourceType" DEFAULT 'Declarative'::public."DBResourceType" NOT NULL,
    "definitionUpdatedAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "exampleValue" text
);


ALTER TABLE public."UserProperty" OWNER TO postgres;

--
-- Name: UserPropertyAssignment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."UserPropertyAssignment" (
    "userId" text NOT NULL,
    "userPropertyId" uuid NOT NULL,
    value text NOT NULL,
    "workspaceId" uuid NOT NULL
);


ALTER TABLE public."UserPropertyAssignment" OWNER TO postgres;

--
-- Name: Workspace; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Workspace" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    domain text,
    type public."WorkspaceType" DEFAULT 'Root'::public."WorkspaceType" NOT NULL,
    "externalId" text,
    status public."WorkspaceStatus" DEFAULT 'Active'::public."WorkspaceStatus" NOT NULL,
    "parentWorkspaceId" uuid
);


ALTER TABLE public."Workspace" OWNER TO postgres;

--
-- Name: WorkspaceMembeAccount; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."WorkspaceMembeAccount" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "workspaceMemberId" uuid NOT NULL,
    provider text NOT NULL,
    "providerAccountId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."WorkspaceMembeAccount" OWNER TO postgres;

--
-- Name: WorkspaceMember; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."WorkspaceMember" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email text,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "emailVerified" boolean DEFAULT false NOT NULL,
    image text,
    name text,
    nickname text,
    "lastWorkspaceId" uuid
);


ALTER TABLE public."WorkspaceMember" OWNER TO postgres;

--
-- Name: WorkspaceMemberRole; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."WorkspaceMemberRole" (
    "workspaceId" uuid NOT NULL,
    "workspaceMemberId" uuid NOT NULL,
    role public."DBRoleType" DEFAULT 'Viewer'::public."DBRoleType" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."WorkspaceMemberRole" OWNER TO postgres;

--
-- Name: WorkspaceRelation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."WorkspaceRelation" (
    "parentWorkspaceId" uuid NOT NULL,
    "childWorkspaceId" uuid NOT NULL
);


ALTER TABLE public."WorkspaceRelation" OWNER TO postgres;

--
-- Name: WriteKey; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."WriteKey" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "workspaceId" uuid NOT NULL,
    "secretId" uuid NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."WriteKey" OWNER TO postgres;

--
-- Name: __drizzle_migrations id; Type: DEFAULT; Schema: drizzle; Owner: postgres
--

ALTER TABLE ONLY drizzle.__drizzle_migrations ALTER COLUMN id SET DEFAULT nextval('drizzle.__drizzle_migrations_id_seq'::regclass);


--
-- Data for Name: __drizzle_migrations; Type: TABLE DATA; Schema: drizzle; Owner: postgres
--

COPY drizzle.__drizzle_migrations (id, hash, created_at) FROM stdin;
1	412fb119b379a4d609f8946d3a85d1b429d98e12e6dbadde41dbb03ae0a85f4c	1736548699659
2	e0405f68b6deafb8029d023526260f1d28d380a91ad12c216eaedc3189d6ebec	1736555146970
3	424bc45b7277b1535b2cc6a79c9fa217d3f85bb272a6e92473182d0a4cf0dac1	1736883565040
4	5c43425466af045af4d9e9be87290a126f551e9435a39afbafdafd01f9373aa0	1737081608502
5	73e39c1be049fdb2d095c9f7812f82ddd581cec15ce1cc1e58803a68976952ea	1737210150661
6	a6dcb765a3d609a0b89ac10aefe3756a7ae1f2d30e00741b5bec5a524659357c	1738535212232
\.


--
-- Data for Name: AdminApiKey; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AdminApiKey" (id, "workspaceId", name, "secretId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Broadcast; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Broadcast" (id, "workspaceId", "segmentId", name, "triggeredAt", "createdAt", "updatedAt", "journeyId", "messageTemplateId", status) FROM stdin;
\.


--
-- Data for Name: ComponentConfiguration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ComponentConfiguration" (id, "workspaceId", name, definition, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ComputedPropertyPeriod; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ComputedPropertyPeriod" (id, "workspaceId", type, "computedPropertyId", version, "from", "to", step, "createdAt") FROM stdin;
459a15c0-30e9-414b-94ad-50d3a9a1571b	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Segment	e4083a5d-2964-4154-a6d6-b8b2c2fda62a	1768478106665	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ComputeState	2026-01-21 21:58:56.698
3cfd123c-019e-426c-a54e-b599f10e2db3	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Segment	643784d3-b136-4e52-8278-a8bf2a868f4d	1768478106665	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ComputeState	2026-01-21 21:58:56.698
11900534-32c5-4dc9-8828-7b496705a781	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Segment	d4567f98-8ab0-4678-aa32-6160852b756d	1768478106665	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ComputeState	2026-01-21 21:58:56.698
db6a5b2e-6a81-4581-a207-3cd62749b4fe	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	a21d3840-054f-46c1-a76c-ea0707b3af92	1768478106628	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ComputeState	2026-01-21 21:58:56.698
d0c3ddbf-8566-475d-92f5-fe78c3abb45a	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	ac40f2a9-965b-44fa-8613-2a3dacd2091f	1768478106632	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ComputeState	2026-01-21 21:58:56.698
5bbec4df-2091-45ca-a490-c1819d0a0fe5	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	14dd17ca-e207-4581-94e2-ad971ecd439c	1768478106636	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ComputeState	2026-01-21 21:58:56.698
a47449f7-f808-42cc-b302-b69bfeead36c	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	26c92ce1-b58a-4565-82f1-d380d2df7ebc	1768478106637	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ComputeState	2026-01-21 21:58:56.698
a6cde6e4-0526-44b9-9d54-503adc36125e	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	8c5a0d79-7c08-4a59-9519-f5574e9b94c3	1768478106637	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ComputeState	2026-01-21 21:58:56.698
0e3949ea-4132-4c42-8533-e579bc4dfb53	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	1d2a93e4-5f23-4a64-8d1d-0df8dda32281	1768478106637	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ComputeState	2026-01-21 21:58:56.698
f1810118-7754-4b7c-a1be-9b9611127527	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	242eea5d-bea0-4189-908e-993673541106	1768478106637	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ComputeState	2026-01-21 21:58:56.698
892c6ebd-2a5d-4399-a21e-fc2513a0f81e	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	dee0d2f8-0c9e-4ccd-8e9e-e1c7dcb1c2de	1768478106638	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ComputeState	2026-01-21 21:58:56.698
aa4caa75-8daa-4678-b781-e6a53200c654	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	01ba78de-9c91-409d-98cd-99ec64f8df25	1768478106639	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ComputeState	2026-01-21 21:58:56.698
66c86371-b104-4b02-ad78-6f13c18b70b9	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	88dafe10-9e97-4b06-bcb9-e1ea9d6a077d	1768478106640	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ComputeState	2026-01-21 21:58:56.698
fbc0a3ce-b147-43fb-b0fb-7dc00edb15e5	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Segment	e4083a5d-2964-4154-a6d6-b8b2c2fda62a	1768478106665	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ComputeAssignments	2026-01-21 21:58:56.698
f3038ebb-4dba-4064-a45e-5c5c82774eb1	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Segment	643784d3-b136-4e52-8278-a8bf2a868f4d	1768478106665	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ComputeAssignments	2026-01-21 21:58:56.698
ce4955cf-ffbe-4773-a3f6-43d37688d40a	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Segment	d4567f98-8ab0-4678-aa32-6160852b756d	1768478106665	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ComputeAssignments	2026-01-21 21:58:56.698
b4ff015e-8353-4e51-8c92-a20c7188e6a5	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	a21d3840-054f-46c1-a76c-ea0707b3af92	1768478106628	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ComputeAssignments	2026-01-21 21:58:56.698
ce949050-cfd5-4f5b-8c0a-d7f176e19643	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	ac40f2a9-965b-44fa-8613-2a3dacd2091f	1768478106632	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ComputeAssignments	2026-01-21 21:58:56.698
88b0a658-b3bd-4231-8795-2fd60c2703fa	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	14dd17ca-e207-4581-94e2-ad971ecd439c	1768478106636	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ComputeAssignments	2026-01-21 21:58:56.698
164933bf-b15b-40f7-97d9-a673b6199c58	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	26c92ce1-b58a-4565-82f1-d380d2df7ebc	1768478106637	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ComputeAssignments	2026-01-21 21:58:56.698
f5077e17-e4e5-4433-8543-983d26ed1480	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	8c5a0d79-7c08-4a59-9519-f5574e9b94c3	1768478106637	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ComputeAssignments	2026-01-21 21:58:56.698
f06a08ef-3f05-45ff-89c5-91c90fdfc13b	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	1d2a93e4-5f23-4a64-8d1d-0df8dda32281	1768478106637	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ComputeAssignments	2026-01-21 21:58:56.698
10ff75a8-1da5-4bfa-beea-4a15171b8539	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	242eea5d-bea0-4189-908e-993673541106	1768478106637	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ComputeAssignments	2026-01-21 21:58:56.698
4fa39b84-9a62-4246-abea-e7b52dae0838	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	dee0d2f8-0c9e-4ccd-8e9e-e1c7dcb1c2de	1768478106638	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ComputeAssignments	2026-01-21 21:58:56.698
26f53e05-ef46-4da4-8861-dd553ae53e05	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	01ba78de-9c91-409d-98cd-99ec64f8df25	1768478106639	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ComputeAssignments	2026-01-21 21:58:56.698
f1fd38cd-cc08-4753-b093-cb7caf25cfe1	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	88dafe10-9e97-4b06-bcb9-e1ea9d6a077d	1768478106640	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ComputeAssignments	2026-01-21 21:58:56.698
750f4072-f721-492f-9aba-272db87cad23	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Segment	e4083a5d-2964-4154-a6d6-b8b2c2fda62a	1768478106665	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ProcessAssignments	2026-01-21 21:58:56.698
1d1e897d-45f4-41cf-82d9-4de8201f3697	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Segment	643784d3-b136-4e52-8278-a8bf2a868f4d	1768478106665	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ProcessAssignments	2026-01-21 21:58:56.698
cb86094b-e085-44ca-98e6-4ef23ab0c507	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Segment	d4567f98-8ab0-4678-aa32-6160852b756d	1768478106665	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ProcessAssignments	2026-01-21 21:58:56.698
83466a5b-39f6-48ae-8192-84ed950aab05	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	a21d3840-054f-46c1-a76c-ea0707b3af92	1768478106628	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ProcessAssignments	2026-01-21 21:58:56.698
02e9cc1f-fe57-4b4f-b896-29af23d4eafe	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	ac40f2a9-965b-44fa-8613-2a3dacd2091f	1768478106632	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ProcessAssignments	2026-01-21 21:58:56.698
465c3d96-007f-4826-9733-2c30e04ae9bf	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	14dd17ca-e207-4581-94e2-ad971ecd439c	1768478106636	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ProcessAssignments	2026-01-21 21:58:56.698
87a84364-6267-4457-8776-b517b67b9069	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	26c92ce1-b58a-4565-82f1-d380d2df7ebc	1768478106637	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ProcessAssignments	2026-01-21 21:58:56.698
151e9627-3660-4304-abc0-68205454fcba	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	8c5a0d79-7c08-4a59-9519-f5574e9b94c3	1768478106637	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ProcessAssignments	2026-01-21 21:58:56.698
21562b35-aa52-4a37-918d-04cad9218f1f	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	1d2a93e4-5f23-4a64-8d1d-0df8dda32281	1768478106637	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ProcessAssignments	2026-01-21 21:58:56.698
5235d834-ec47-46c1-828c-e844f1d40948	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	242eea5d-bea0-4189-908e-993673541106	1768478106637	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ProcessAssignments	2026-01-21 21:58:56.698
13960e15-b05d-4808-bfc7-aceed9b98275	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	dee0d2f8-0c9e-4ccd-8e9e-e1c7dcb1c2de	1768478106638	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ProcessAssignments	2026-01-21 21:58:56.698
531fe124-99d6-441d-8e8b-8f39e142b525	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	01ba78de-9c91-409d-98cd-99ec64f8df25	1768478106639	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ProcessAssignments	2026-01-21 21:58:56.698
14413e5e-aadd-4b25-9986-9ced6e481e6a	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	88dafe10-9e97-4b06-bcb9-e1ea9d6a077d	1768478106640	2026-01-21 21:56:41.937	2026-01-21 21:58:56.698	ProcessAssignments	2026-01-21 21:58:56.698
3b758537-87e0-418a-a35d-d2d5b5eab26a	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Segment	e4083a5d-2964-4154-a6d6-b8b2c2fda62a	1768478106665	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ComputeState	2026-01-21 21:56:41.937
21069295-6eb3-4f84-b344-00cf3650393c	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Segment	643784d3-b136-4e52-8278-a8bf2a868f4d	1768478106665	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ComputeState	2026-01-21 21:56:41.937
1e94c9d9-e9ec-4da6-a100-eeed5b035a02	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Segment	d4567f98-8ab0-4678-aa32-6160852b756d	1768478106665	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ComputeState	2026-01-21 21:56:41.937
7c4c49d8-062c-475a-aa57-a249330fe596	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	a21d3840-054f-46c1-a76c-ea0707b3af92	1768478106628	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ComputeState	2026-01-21 21:56:41.937
8a8a3621-edca-44f5-8669-1fc4eb00128b	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	ac40f2a9-965b-44fa-8613-2a3dacd2091f	1768478106632	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ComputeState	2026-01-21 21:56:41.937
d5154320-6f43-4476-8764-36a7cd4a2d45	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	14dd17ca-e207-4581-94e2-ad971ecd439c	1768478106636	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ComputeState	2026-01-21 21:56:41.937
5138e63f-8a03-4704-929d-dd409b8a6ba2	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	26c92ce1-b58a-4565-82f1-d380d2df7ebc	1768478106637	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ComputeState	2026-01-21 21:56:41.937
9e16ec89-3dad-42f6-9061-5c00a30f6c13	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	8c5a0d79-7c08-4a59-9519-f5574e9b94c3	1768478106637	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ComputeState	2026-01-21 21:56:41.937
df10d5d0-7dc0-47ab-9c3b-87a5664aea93	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	1d2a93e4-5f23-4a64-8d1d-0df8dda32281	1768478106637	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ComputeState	2026-01-21 21:56:41.937
af5098c7-d3b2-4134-9da1-f07790a5c1b0	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	242eea5d-bea0-4189-908e-993673541106	1768478106637	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ComputeState	2026-01-21 21:56:41.937
1e0b107c-d630-494e-bf10-391e32659759	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	dee0d2f8-0c9e-4ccd-8e9e-e1c7dcb1c2de	1768478106638	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ComputeState	2026-01-21 21:56:41.937
586be42c-f7af-4951-a856-22b786106623	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	01ba78de-9c91-409d-98cd-99ec64f8df25	1768478106639	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ComputeState	2026-01-21 21:56:41.937
8b680afe-12bc-49c0-b109-54b5cc92c85f	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	88dafe10-9e97-4b06-bcb9-e1ea9d6a077d	1768478106640	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ComputeState	2026-01-21 21:56:41.937
4dc3934d-0d47-4281-ac34-76bc2c150c91	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	a21d3840-054f-46c1-a76c-ea0707b3af92	1768478106628	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ProcessAssignments	2026-01-21 22:00:57.57
95ef8ad3-e439-41c7-b08f-36c4995805b6	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	ac40f2a9-965b-44fa-8613-2a3dacd2091f	1768478106632	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ProcessAssignments	2026-01-21 22:00:57.57
4df116d7-63c1-4637-a1f4-3386a94e0d77	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	14dd17ca-e207-4581-94e2-ad971ecd439c	1768478106636	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ProcessAssignments	2026-01-21 22:00:57.57
481f5218-3851-497b-84b5-847ca8a95600	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	26c92ce1-b58a-4565-82f1-d380d2df7ebc	1768478106637	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ProcessAssignments	2026-01-21 22:00:57.57
f2d07224-7b47-4b6a-b125-858c1f4a8b92	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Segment	e4083a5d-2964-4154-a6d6-b8b2c2fda62a	1768478106665	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ComputeAssignments	2026-01-21 21:56:41.937
80d52708-1e56-4c29-8659-bffab01e1075	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Segment	643784d3-b136-4e52-8278-a8bf2a868f4d	1768478106665	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ComputeAssignments	2026-01-21 21:56:41.937
7fa6a429-5ded-49ee-a22d-c3b664dcddc4	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Segment	d4567f98-8ab0-4678-aa32-6160852b756d	1768478106665	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ComputeAssignments	2026-01-21 21:56:41.937
965292b6-3721-4aec-9d39-d2fc7f3e207e	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	a21d3840-054f-46c1-a76c-ea0707b3af92	1768478106628	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ComputeAssignments	2026-01-21 21:56:41.937
53551738-7207-49b4-919b-15fc63c93acb	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	ac40f2a9-965b-44fa-8613-2a3dacd2091f	1768478106632	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ComputeAssignments	2026-01-21 21:56:41.937
a0928ccb-c23f-4592-80a1-95d531a3ff04	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	14dd17ca-e207-4581-94e2-ad971ecd439c	1768478106636	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ComputeAssignments	2026-01-21 21:56:41.937
db226c2d-a3fb-4841-8840-688a8e3b0e83	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	26c92ce1-b58a-4565-82f1-d380d2df7ebc	1768478106637	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ComputeAssignments	2026-01-21 21:56:41.937
97ab92f5-0059-402f-8455-6c9154afac50	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	8c5a0d79-7c08-4a59-9519-f5574e9b94c3	1768478106637	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ComputeAssignments	2026-01-21 21:56:41.937
6a2f253e-bd42-4667-b472-7929251ff0cf	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	1d2a93e4-5f23-4a64-8d1d-0df8dda32281	1768478106637	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ComputeAssignments	2026-01-21 21:56:41.937
30d0e865-35b0-4f44-be5a-4c8f8e3cdf6a	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	242eea5d-bea0-4189-908e-993673541106	1768478106637	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ComputeAssignments	2026-01-21 21:56:41.937
b6bc7b92-3b1e-4b54-b9d1-a087c3718058	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	dee0d2f8-0c9e-4ccd-8e9e-e1c7dcb1c2de	1768478106638	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ComputeAssignments	2026-01-21 21:56:41.937
f4d3166f-b176-4870-9ea9-386e50aea888	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	01ba78de-9c91-409d-98cd-99ec64f8df25	1768478106639	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ComputeAssignments	2026-01-21 21:56:41.937
b0276509-05b2-4b43-abc3-44e950955cad	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	88dafe10-9e97-4b06-bcb9-e1ea9d6a077d	1768478106640	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ComputeAssignments	2026-01-21 21:56:41.937
6bb73177-89d8-4bf1-a9f6-230fd765f236	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Segment	e4083a5d-2964-4154-a6d6-b8b2c2fda62a	1768478106665	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ComputeState	2026-01-21 22:00:57.57
f1159781-e202-467d-889d-6ef810550b79	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Segment	643784d3-b136-4e52-8278-a8bf2a868f4d	1768478106665	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ComputeState	2026-01-21 22:00:57.57
4a9cce7c-1e1d-4192-82a3-6878fdfd0ee0	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Segment	d4567f98-8ab0-4678-aa32-6160852b756d	1768478106665	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ComputeState	2026-01-21 22:00:57.57
8b464085-12d0-45ff-a3e6-f9fc3687ad0d	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	a21d3840-054f-46c1-a76c-ea0707b3af92	1768478106628	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ComputeState	2026-01-21 22:00:57.57
85e43827-edfa-48b6-a8f0-60be2b8ec915	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	ac40f2a9-965b-44fa-8613-2a3dacd2091f	1768478106632	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ComputeState	2026-01-21 22:00:57.57
5a850b0a-22b2-4e52-b439-725e257e2ac9	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	14dd17ca-e207-4581-94e2-ad971ecd439c	1768478106636	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ComputeState	2026-01-21 22:00:57.57
f77720f4-ada5-4d49-8e92-551cb0066d6c	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	26c92ce1-b58a-4565-82f1-d380d2df7ebc	1768478106637	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ComputeState	2026-01-21 22:00:57.57
0742c7b7-364d-4d9b-810c-65020ddfca12	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Segment	e4083a5d-2964-4154-a6d6-b8b2c2fda62a	1768478106665	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ProcessAssignments	2026-01-21 21:56:41.937
b99a0eb5-aa6d-489c-9d78-921c2307754f	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Segment	643784d3-b136-4e52-8278-a8bf2a868f4d	1768478106665	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ProcessAssignments	2026-01-21 21:56:41.937
3207d1e3-262c-4a21-93d8-0754203213fe	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Segment	d4567f98-8ab0-4678-aa32-6160852b756d	1768478106665	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ProcessAssignments	2026-01-21 21:56:41.937
c3a71a2a-7a86-443b-ac25-76edf04d87e1	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	a21d3840-054f-46c1-a76c-ea0707b3af92	1768478106628	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ProcessAssignments	2026-01-21 21:56:41.937
13ae7a2d-6468-4597-bfef-95a7126d083b	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	ac40f2a9-965b-44fa-8613-2a3dacd2091f	1768478106632	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ProcessAssignments	2026-01-21 21:56:41.937
51886b18-7d67-4e53-b8ba-be5db8bdcb8f	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	14dd17ca-e207-4581-94e2-ad971ecd439c	1768478106636	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ProcessAssignments	2026-01-21 21:56:41.937
fb486be3-faeb-4ed3-8033-c433e3770242	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	26c92ce1-b58a-4565-82f1-d380d2df7ebc	1768478106637	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ProcessAssignments	2026-01-21 21:56:41.937
7bb8d82c-bf03-4f21-8a95-d16d2c761265	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	8c5a0d79-7c08-4a59-9519-f5574e9b94c3	1768478106637	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ProcessAssignments	2026-01-21 21:56:41.937
9dbce7bc-c89d-43e7-8927-460578d9b6b4	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	1d2a93e4-5f23-4a64-8d1d-0df8dda32281	1768478106637	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ProcessAssignments	2026-01-21 21:56:41.937
475eff1e-a3ac-408b-87ea-a30fe7cc3946	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	242eea5d-bea0-4189-908e-993673541106	1768478106637	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ProcessAssignments	2026-01-21 21:56:41.937
2b6d58f6-5f91-4684-aeb4-2d5d12acda7a	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	dee0d2f8-0c9e-4ccd-8e9e-e1c7dcb1c2de	1768478106638	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ProcessAssignments	2026-01-21 21:56:41.937
d8b95d3a-7807-441a-9e35-05487b3e2d6b	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	01ba78de-9c91-409d-98cd-99ec64f8df25	1768478106639	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ProcessAssignments	2026-01-21 21:56:41.937
50ecc503-e3ca-49bb-be94-7560a0f86a17	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	88dafe10-9e97-4b06-bcb9-e1ea9d6a077d	1768478106640	2026-01-16 13:40:38.382	2026-01-21 21:56:41.937	ProcessAssignments	2026-01-21 21:56:41.937
03bf3e6b-39c5-41d8-b411-bda80b8a9533	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	8c5a0d79-7c08-4a59-9519-f5574e9b94c3	1768478106637	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ComputeState	2026-01-21 22:00:57.57
57aedaa1-f3b5-4e6c-a502-916f27e0ad6b	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	1d2a93e4-5f23-4a64-8d1d-0df8dda32281	1768478106637	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ComputeState	2026-01-21 22:00:57.57
b4c795ae-31ac-4973-89de-9a57a140916e	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	242eea5d-bea0-4189-908e-993673541106	1768478106637	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ComputeState	2026-01-21 22:00:57.57
68c1e8c4-fd89-4643-a843-2ca02cc96b26	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	dee0d2f8-0c9e-4ccd-8e9e-e1c7dcb1c2de	1768478106638	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ComputeState	2026-01-21 22:00:57.57
a6473c31-6ed4-4dc9-8594-69444147bbab	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	01ba78de-9c91-409d-98cd-99ec64f8df25	1768478106639	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ComputeState	2026-01-21 22:00:57.57
878c5009-28a3-4989-a7f7-075969fcdd1c	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	88dafe10-9e97-4b06-bcb9-e1ea9d6a077d	1768478106640	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ComputeState	2026-01-21 22:00:57.57
d6e41dea-33f8-4353-aeb4-2263edaa41f8	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Segment	e4083a5d-2964-4154-a6d6-b8b2c2fda62a	1768478106665	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ComputeAssignments	2026-01-21 22:00:57.57
413716c9-51b1-4491-b27d-d6d4a3b2d4db	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Segment	643784d3-b136-4e52-8278-a8bf2a868f4d	1768478106665	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ComputeAssignments	2026-01-21 22:00:57.57
88e5470d-5c85-4053-beea-64e1d3a0d176	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Segment	d4567f98-8ab0-4678-aa32-6160852b756d	1768478106665	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ComputeAssignments	2026-01-21 22:00:57.57
e60d1046-2950-468b-8f85-4b12e9d93214	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	a21d3840-054f-46c1-a76c-ea0707b3af92	1768478106628	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ComputeAssignments	2026-01-21 22:00:57.57
8609fced-7a5c-41aa-a795-a1c9a493ddaa	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	ac40f2a9-965b-44fa-8613-2a3dacd2091f	1768478106632	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ComputeAssignments	2026-01-21 22:00:57.57
802cb0f3-a143-44a2-86ff-93ce480f979d	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	14dd17ca-e207-4581-94e2-ad971ecd439c	1768478106636	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ComputeAssignments	2026-01-21 22:00:57.57
7da9ccd5-d1ba-4c4f-9e16-816ef47dc3b6	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	26c92ce1-b58a-4565-82f1-d380d2df7ebc	1768478106637	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ComputeAssignments	2026-01-21 22:00:57.57
ef0318cb-32a3-4543-acd5-cfcac43029f9	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	8c5a0d79-7c08-4a59-9519-f5574e9b94c3	1768478106637	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ComputeAssignments	2026-01-21 22:00:57.57
c66955f7-7d9c-4979-9b52-f33492b2b24e	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	1d2a93e4-5f23-4a64-8d1d-0df8dda32281	1768478106637	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ComputeAssignments	2026-01-21 22:00:57.57
b787f0c2-f428-49a9-894e-f8a71643f017	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	242eea5d-bea0-4189-908e-993673541106	1768478106637	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ComputeAssignments	2026-01-21 22:00:57.57
fabb7dc7-9f7a-45e6-a542-85583110f467	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	dee0d2f8-0c9e-4ccd-8e9e-e1c7dcb1c2de	1768478106638	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ComputeAssignments	2026-01-21 22:00:57.57
8aad73fa-4b15-42c9-b283-11c1b7368e52	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	01ba78de-9c91-409d-98cd-99ec64f8df25	1768478106639	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ComputeAssignments	2026-01-21 22:00:57.57
deff0844-e8ee-4469-8028-7c7bab9ce846	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	88dafe10-9e97-4b06-bcb9-e1ea9d6a077d	1768478106640	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ComputeAssignments	2026-01-21 22:00:57.57
253ab657-2bb4-48b0-9b93-0655e8ed3455	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Segment	e4083a5d-2964-4154-a6d6-b8b2c2fda62a	1768478106665	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ProcessAssignments	2026-01-21 22:00:57.57
0f1b5cc4-f58d-4068-98a0-59c084026ff5	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Segment	643784d3-b136-4e52-8278-a8bf2a868f4d	1768478106665	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ProcessAssignments	2026-01-21 22:00:57.57
891e9cc5-6bf6-4ddd-ae41-3bf82589d2ad	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Segment	d4567f98-8ab0-4678-aa32-6160852b756d	1768478106665	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ProcessAssignments	2026-01-21 22:00:57.57
5cf3f936-4fff-4378-a89a-bd0b50fef1a6	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	8c5a0d79-7c08-4a59-9519-f5574e9b94c3	1768478106637	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ProcessAssignments	2026-01-21 22:00:57.57
b1ed7d2f-d60a-4cb2-af86-43ef740696f5	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	1d2a93e4-5f23-4a64-8d1d-0df8dda32281	1768478106637	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ProcessAssignments	2026-01-21 22:00:57.57
0755e5d0-e4fb-4c22-b77d-150bedb54444	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	242eea5d-bea0-4189-908e-993673541106	1768478106637	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ProcessAssignments	2026-01-21 22:00:57.57
0da7cb73-a94d-4f43-a38a-f75df848238d	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	dee0d2f8-0c9e-4ccd-8e9e-e1c7dcb1c2de	1768478106638	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ProcessAssignments	2026-01-21 22:00:57.57
4e7e1274-98c0-41bf-9b8b-a3dda6788ca4	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	01ba78de-9c91-409d-98cd-99ec64f8df25	1768478106639	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ProcessAssignments	2026-01-21 22:00:57.57
7dddd74a-7188-45a4-a64d-82868ba20e30	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	UserProperty	88dafe10-9e97-4b06-bcb9-e1ea9d6a077d	1768478106640	2026-01-21 21:58:56.698	2026-01-21 22:00:57.57	ProcessAssignments	2026-01-21 22:00:57.57
\.


--
-- Data for Name: DefaultEmailProvider; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."DefaultEmailProvider" ("workspaceId", "emailProviderId", "createdAt", "updatedAt", "fromAddress") FROM stdin;
2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	386a83b2-6ec0-4139-96f2-a3e30ab059e8	2026-01-15 11:55:06.664	2026-01-15 11:55:06.664	\N
\.


--
-- Data for Name: DefaultSmsProvider; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."DefaultSmsProvider" ("workspaceId", "smsProviderId", "createdAt", "updatedAt") FROM stdin;
2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	490976b6-f353-4795-b892-e9541424ac07	2026-01-15 11:55:06.665	2026-01-15 11:55:06.665
\.


--
-- Data for Name: EmailProvider; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."EmailProvider" (id, "workspaceId", type, "apiKey", "createdAt", "updatedAt", "secretId") FROM stdin;
a14dceea-a3d6-4b84-81dd-cb4d48ed6ec4	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	SendGrid	\N	2026-01-15 11:55:06.64	2026-01-15 11:55:06.64	963b58a0-d854-4326-900b-63854c1faa78
bb8f38f2-0fb0-40e7-937d-17dde7917051	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Resend	\N	2026-01-15 11:55:06.642	2026-01-15 11:55:06.642	a9d66a57-fd7a-48ef-939b-e7402622739c
32931a2a-761e-42e4-b02a-cb84337bc4c6	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	PostMark	\N	2026-01-15 11:55:06.642	2026-01-15 11:55:06.642	24aa89d2-f7a1-4532-bfe1-c0a5ccf8c11c
36fcda3b-87a0-4b15-a0ef-b6c05d0ed3bc	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Smtp	\N	2026-01-15 11:55:06.643	2026-01-15 11:55:06.643	48bd407e-8ef2-40d2-aec6-69854cd5158c
386a83b2-6ec0-4139-96f2-a3e30ab059e8	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Test	\N	2026-01-15 11:55:06.643	2026-01-15 11:55:06.643	58b507d5-9858-4cd9-895e-ef4efbcf093e
2fc8a1bf-436b-4274-aee7-cff38063ca0c	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	MailChimp	\N	2026-01-15 11:55:06.643	2026-01-15 11:55:06.643	20dd5be3-8ab0-4d44-98a7-6be77bbd70a5
235ce65e-7c7d-44ec-8d24-6cf87afd00db	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	AmazonSes	\N	2026-01-15 11:55:06.642	2026-01-15 11:55:06.642	9af22c31-b873-4395-87ad-e3661a447835
\.


--
-- Data for Name: EmailTemplate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."EmailTemplate" (id, "workspaceId", name, "from", subject, body, "createdAt", "updatedAt", "replyTo") FROM stdin;
\.


--
-- Data for Name: Feature; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Feature" ("workspaceId", name, enabled, "createdAt", "updatedAt", config) FROM stdin;
\.


--
-- Data for Name: Integration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Integration" (id, "workspaceId", name, definition, enabled, "createdAt", "updatedAt", "definitionUpdatedAt") FROM stdin;
\.


--
-- Data for Name: Journey; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Journey" (id, "workspaceId", name, status, definition, "createdAt", "updatedAt", "resourceType", "canRunMultiple", draft, "statusUpdatedAt") FROM stdin;
2318c710-3bf4-4640-8238-82cb8b8b671f	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	New Journey - 2318c710-3bf4-4640-8238-82cb8b8b671f	NotStarted	\N	2026-01-15 11:55:35.629	2026-01-15 11:56:24.529	Declarative	f	{"edges": [{"data": {"type": "JourneyUiDefinitionEdgeProps"}, "source": "EntryUiNode", "target": "02e53d2e-0497-468c-8742-ecbb2b4f8a30"}, {"data": {"type": "JourneyUiDefinitionEdgeProps"}, "source": "02e53d2e-0497-468c-8742-ecbb2b4f8a30", "target": "ExitNode"}], "nodes": [{"id": "EntryUiNode", "data": {"type": "JourneyUiNodeDefinitionProps", "nodeTypeProps": {"type": "EntryUiNode", "variant": {"type": "EntryNode"}}}}, {"id": "ExitNode", "data": {"type": "JourneyUiNodeDefinitionProps", "nodeTypeProps": {"type": "ExitNode"}}}, {"id": "02e53d2e-0497-468c-8742-ecbb2b4f8a30", "data": {"type": "JourneyUiNodeDefinitionProps", "nodeTypeProps": {"type": "DelayNode", "variant": {"type": "Second"}}}}]}	\N
\.


--
-- Data for Name: MessageTemplate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."MessageTemplate" (id, "workspaceId", name, definition, "createdAt", "updatedAt", "resourceType", draft) FROM stdin;
ab3136d3-ae40-5afb-9e7e-7c01daba956a	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Welcome Email	{"body": "<mjml>\\n  <mj-head>\\n    <mj-style inline=\\"inline\\">\\n      .df-unsubscribe {\\n        color: #a8a8a8;\\n        text-decoration: underline;\\n      }\\n    </mj-style>\\n  </mj-head>\\n  <mj-body>\\n    <mj-section>\\n      <mj-column>\\n        <mj-text font-size=\\"16px\\" align=\\"left\\">\\n          Hi {{ user.firstName | default: \\"there\\"}}<br/><br/>\\n          A warm welcome to CompanyName! During this 14-day trial, you have the opportunity to use our product to make a difference in your day-to-day. We'll be providing you with a VIP tour of how to make the most of CompanyName.<br/><br/>\\n          To get started, we'll integrate your data into the platform.<br/><br/>\\nTake a look at our <a href=\\"#\\" target=\\"_blank\\">docs</a> for more info.\\n        </mj-text>\\n      </mj-column>\\n    </mj-section>\\n    <mj-section padding-top=\\"10px\\">\\n      <mj-column>\\n        <mj-text font-size=\\"12px\\" align=\\"center\\" color=\\"#a8a8a8\\">\\n          MyCompany, Inc., 40 Rosewood Lane, New York, NY 10003<br/>\\n          Don't want to receive these emails? You can {% unsubscribe_link %} from them here.<br/>\\n          Powered by Dittofeed.\\n        </mj-text>\\n      </mj-column>\\n    </mj-section>\\n  </mj-body>\\n</mjml>\\n", "from": "hello@mycompany.com", "type": "Email", "subject": "Hi {{ user.firstName | default: \\"there\\"}}!"}	2026-01-15 11:55:06.639	2026-01-21 21:56:55.444	Declarative	\N
\.


--
-- Data for Name: OauthToken; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."OauthToken" (id, "workspaceId", name, "refreshToken", "accessToken", "expiresIn", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Secret; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Secret" (id, "workspaceId", name, value, "createdAt", "updatedAt", "configValue") FROM stdin;
85dcc317-d560-4be9-aea6-fd7ffa0a4375	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	default-write-key	58e6d6dc5f2f09f5	2026-01-15 11:55:06.616	2026-01-15 11:55:06.616	\N
5bccba9b-ca66-4363-8ca8-a4f62b0d1bed	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	subscription-key	8e96003557e64cc3	2026-01-15 11:55:06.638	2026-01-15 11:55:06.638	\N
963b58a0-d854-4326-900b-63854c1faa78	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	sendgrid	\N	2026-01-15 11:55:06.64	2026-01-15 11:55:06.64	{"type": "SendGrid"}
a9d66a57-fd7a-48ef-939b-e7402622739c	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	resend	\N	2026-01-15 11:55:06.642	2026-01-15 11:55:06.642	{"type": "Resend"}
24aa89d2-f7a1-4532-bfe1-c0a5ccf8c11c	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	postmark	\N	2026-01-15 11:55:06.642	2026-01-15 11:55:06.642	{"type": "PostMark"}
48bd407e-8ef2-40d2-aec6-69854cd5158c	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	smtp	\N	2026-01-15 11:55:06.643	2026-01-15 11:55:06.643	{"type": "Smtp"}
20dd5be3-8ab0-4d44-98a7-6be77bbd70a5	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	mailchimp	\N	2026-01-15 11:55:06.643	2026-01-15 11:55:06.643	{"type": "MailChimp"}
58b507d5-9858-4cd9-895e-ef4efbcf093e	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	EmailTestProvider	\N	2026-01-15 11:55:06.643	2026-01-15 11:55:06.643	{"type": "Test"}
9af22c31-b873-4395-87ad-e3661a447835	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	amazonses	\N	2026-01-15 11:55:06.642	2026-01-15 11:55:06.642	{"type": "AmazonSes"}
541bdfcd-ae68-4e93-a1f0-aa53af408feb	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	twilio-key	\N	2026-01-15 11:55:06.649	2026-01-15 11:55:06.649	{"type": "Twilio"}
9ebfa3fe-6c14-48f7-a414-0bc3f495f6ff	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	SmsTestProvider	\N	2026-01-15 11:55:06.649	2026-01-15 11:55:06.649	{"type": "Test"}
\.


--
-- Data for Name: Segment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Segment" (id, "workspaceId", name, definition, "createdAt", "updatedAt", "resourceType", "subscriptionGroupId", status, "definitionUpdatedAt") FROM stdin;
e4083a5d-2964-4154-a6d6-b8b2c2fda62a	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	subscriptionGroup-5d6d3873-81c4-5a45-8eb0-aab922db67bd	{"nodes": [], "entryNode": {"id": "1", "type": "SubscriptionGroup", "subscriptionGroupId": "5d6d3873-81c4-5a45-8eb0-aab922db67bd", "subscriptionGroupType": "OptOut"}}	2026-01-15 11:55:06.665	2026-01-21 21:56:55.595	Internal	5d6d3873-81c4-5a45-8eb0-aab922db67bd	Running	2026-01-15 11:55:06.665
d4567f98-8ab0-4678-aa32-6160852b756d	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	subscriptionGroup-e4204b68-90e4-52bd-99de-b3f1197112aa	{"nodes": [], "entryNode": {"id": "1", "type": "SubscriptionGroup", "subscriptionGroupId": "e4204b68-90e4-52bd-99de-b3f1197112aa", "subscriptionGroupType": "OptOut"}}	2026-01-15 11:55:06.665	2026-01-21 21:56:55.598	Internal	e4204b68-90e4-52bd-99de-b3f1197112aa	Running	2026-01-15 11:55:06.665
643784d3-b136-4e52-8278-a8bf2a868f4d	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	subscriptionGroup-c4b90dab-6b3a-536a-b58d-adef47a52d63	{"nodes": [], "entryNode": {"id": "1", "type": "SubscriptionGroup", "subscriptionGroupId": "c4b90dab-6b3a-536a-b58d-adef47a52d63", "subscriptionGroupType": "OptOut"}}	2026-01-15 11:55:06.665	2026-01-21 21:56:55.6	Internal	c4b90dab-6b3a-536a-b58d-adef47a52d63	Running	2026-01-15 11:55:06.665
\.


--
-- Data for Name: SegmentAssignment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SegmentAssignment" ("userId", "inSegment", "workspaceId", "segmentId") FROM stdin;
\.


--
-- Data for Name: SegmentIOConfiguration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SegmentIOConfiguration" (id, "workspaceId", "sharedSecret", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: SmsProvider; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SmsProvider" (id, "workspaceId", "secretId", type, "createdAt", "updatedAt") FROM stdin;
490976b6-f353-4795-b892-e9541424ac07	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	9ebfa3fe-6c14-48f7-a414-0bc3f495f6ff	Test	2026-01-15 11:55:06.649	2026-01-15 11:55:06.649
c6cea901-4e1a-4960-83ca-710ae7967b39	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	541bdfcd-ae68-4e93-a1f0-aa53af408feb	Twilio	2026-01-15 11:55:06.649	2026-01-15 11:55:06.649
\.


--
-- Data for Name: SubscriptionGroup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SubscriptionGroup" (id, "workspaceId", name, type, "createdAt", "updatedAt", channel) FROM stdin;
5d6d3873-81c4-5a45-8eb0-aab922db67bd	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Default - Email	OptOut	2026-01-15 11:55:06.665	2026-01-21 21:56:55.582	Email
e4204b68-90e4-52bd-99de-b3f1197112aa	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Default - SMS	OptOut	2026-01-15 11:55:06.665	2026-01-21 21:56:55.588	Sms
c4b90dab-6b3a-536a-b58d-adef47a52d63	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Default - Mobile Push	OptOut	2026-01-15 11:55:06.665	2026-01-21 21:56:55.59	MobilePush
\.


--
-- Data for Name: UserJourneyEvent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."UserJourneyEvent" (id, "userId", "journeyId", type, "journeyStartedAt", "createdAt", "nodeId", "eventKey", "eventKeyName") FROM stdin;
\.


--
-- Data for Name: UserProperty; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."UserProperty" (id, "workspaceId", name, definition, "createdAt", "updatedAt", "resourceType", "definitionUpdatedAt", "exampleValue") FROM stdin;
a21d3840-054f-46c1-a76c-ea0707b3af92	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	language	{"path": "language", "type": "Trait"}	2026-01-15 11:55:06.628	2026-01-15 11:55:06.628	Declarative	2026-01-15 11:55:06.628	"en-US"
ac40f2a9-965b-44fa-8613-2a3dacd2091f	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	accountManager	{"path": "accountManager", "type": "Trait"}	2026-01-15 11:55:06.632	2026-01-15 11:55:06.632	Declarative	2026-01-15 11:55:06.632	"Jane Johnson"
14dd17ca-e207-4581-94e2-ad971ecd439c	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	latLon	{"path": "latLon", "type": "Trait"}	2026-01-15 11:55:06.636	2026-01-15 11:55:06.636	Declarative	2026-01-15 11:55:06.636	33.812511,-117.9189762
26c92ce1-b58a-4565-82f1-d380d2df7ebc	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	anonymousId	{"type": "AnonymousId"}	2026-01-15 11:55:06.637	2026-01-15 11:55:06.637	Declarative	2026-01-15 11:55:06.637	"b8fa9198-6475-4b18-bb64-aafd0c8b717e"
8c5a0d79-7c08-4a59-9519-f5574e9b94c3	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	phone	{"path": "phone", "type": "Trait"}	2026-01-15 11:55:06.637	2026-01-15 11:55:06.637	Declarative	2026-01-15 11:55:06.637	"8885551234"
1d2a93e4-5f23-4a64-8d1d-0df8dda32281	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	email	{"path": "email", "type": "Trait"}	2026-01-15 11:55:06.637	2026-01-15 11:55:06.637	Declarative	2026-01-15 11:55:06.637	"name@email.com"
242eea5d-bea0-4189-908e-993673541106	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	lastName	{"path": "lastName", "type": "Trait"}	2026-01-15 11:55:06.637	2026-01-15 11:55:06.637	Declarative	2026-01-15 11:55:06.637	"Smith"
dee0d2f8-0c9e-4ccd-8e9e-e1c7dcb1c2de	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	deviceToken	{"path": "deviceToken", "type": "Trait"}	2026-01-15 11:55:06.638	2026-01-15 11:55:06.638	Declarative	2026-01-15 11:55:06.638	"1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef"
01ba78de-9c91-409d-98cd-99ec64f8df25	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	id	{"type": "Id"}	2026-01-15 11:55:06.639	2026-01-15 11:55:06.639	Declarative	2026-01-15 11:55:06.639	"62b44d22-0d14-48bb-80d9-fb5da5b26a0c"
88dafe10-9e97-4b06-bcb9-e1ea9d6a077d	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	firstName	{"path": "firstName", "type": "Trait"}	2026-01-15 11:55:06.64	2026-01-15 11:55:06.64	Declarative	2026-01-15 11:55:06.64	"Matt"
\.


--
-- Data for Name: UserPropertyAssignment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."UserPropertyAssignment" ("userId", "userPropertyId", value, "workspaceId") FROM stdin;
\.


--
-- Data for Name: Workspace; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Workspace" (id, name, "createdAt", "updatedAt", domain, type, "externalId", status, "parentWorkspaceId") FROM stdin;
2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	Default	2026-01-15 11:55:06.598	2026-01-21 21:56:55.405	\N	Root	\N	Active	\N
\.


--
-- Data for Name: WorkspaceMembeAccount; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."WorkspaceMembeAccount" (id, "workspaceMemberId", provider, "providerAccountId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: WorkspaceMember; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."WorkspaceMember" (id, email, "createdAt", "updatedAt", "emailVerified", image, name, nickname, "lastWorkspaceId") FROM stdin;
\.


--
-- Data for Name: WorkspaceMemberRole; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."WorkspaceMemberRole" ("workspaceId", "workspaceMemberId", role, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: WorkspaceRelation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."WorkspaceRelation" ("parentWorkspaceId", "childWorkspaceId") FROM stdin;
\.


--
-- Data for Name: WriteKey; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."WriteKey" (id, "workspaceId", "secretId", "createdAt", "updatedAt") FROM stdin;
41211186-dbba-4cfa-bf8a-ff93e863d2bd	2cdf50a1-1015-490d-bff8-dedf6ff9a0b6	85dcc317-d560-4be9-aea6-fd7ffa0a4375	2026-01-15 11:55:06.616	2026-01-15 11:55:06.616
\.


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE SET; Schema: drizzle; Owner: postgres
--

SELECT pg_catalog.setval('drizzle.__drizzle_migrations_id_seq', 6, true);


--
-- Name: __drizzle_migrations __drizzle_migrations_pkey; Type: CONSTRAINT; Schema: drizzle; Owner: postgres
--

ALTER TABLE ONLY drizzle.__drizzle_migrations
    ADD CONSTRAINT __drizzle_migrations_pkey PRIMARY KEY (id);


--
-- Name: AdminApiKey AdminApiKey_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AdminApiKey"
    ADD CONSTRAINT "AdminApiKey_pkey" PRIMARY KEY (id);


--
-- Name: Broadcast Broadcast_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Broadcast"
    ADD CONSTRAINT "Broadcast_pkey" PRIMARY KEY (id);


--
-- Name: ComponentConfiguration ComponentConfiguration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ComponentConfiguration"
    ADD CONSTRAINT "ComponentConfiguration_pkey" PRIMARY KEY (id);


--
-- Name: ComputedPropertyPeriod ComputedPropertyPeriod_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ComputedPropertyPeriod"
    ADD CONSTRAINT "ComputedPropertyPeriod_pkey" PRIMARY KEY (id);


--
-- Name: EmailProvider EmailProvider_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmailProvider"
    ADD CONSTRAINT "EmailProvider_pkey" PRIMARY KEY (id);


--
-- Name: EmailTemplate EmailTemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmailTemplate"
    ADD CONSTRAINT "EmailTemplate_pkey" PRIMARY KEY (id);


--
-- Name: Integration Integration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Integration"
    ADD CONSTRAINT "Integration_pkey" PRIMARY KEY (id);


--
-- Name: Journey Journey_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Journey"
    ADD CONSTRAINT "Journey_pkey" PRIMARY KEY (id);


--
-- Name: MessageTemplate MessageTemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MessageTemplate"
    ADD CONSTRAINT "MessageTemplate_pkey" PRIMARY KEY (id);


--
-- Name: OauthToken OauthToken_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OauthToken"
    ADD CONSTRAINT "OauthToken_pkey" PRIMARY KEY (id);


--
-- Name: Secret Secret_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Secret"
    ADD CONSTRAINT "Secret_pkey" PRIMARY KEY (id);


--
-- Name: SegmentIOConfiguration SegmentIOConfiguration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SegmentIOConfiguration"
    ADD CONSTRAINT "SegmentIOConfiguration_pkey" PRIMARY KEY (id);


--
-- Name: Segment Segment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Segment"
    ADD CONSTRAINT "Segment_pkey" PRIMARY KEY (id);


--
-- Name: SmsProvider SmsProvider_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SmsProvider"
    ADD CONSTRAINT "SmsProvider_pkey" PRIMARY KEY (id);


--
-- Name: SubscriptionGroup SubscriptionGroup_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SubscriptionGroup"
    ADD CONSTRAINT "SubscriptionGroup_pkey" PRIMARY KEY (id);


--
-- Name: UserJourneyEvent UserJourneyEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserJourneyEvent"
    ADD CONSTRAINT "UserJourneyEvent_pkey" PRIMARY KEY (id);


--
-- Name: UserProperty UserProperty_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserProperty"
    ADD CONSTRAINT "UserProperty_pkey" PRIMARY KEY (id);


--
-- Name: WorkspaceMembeAccount WorkspaceMembeAccount_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WorkspaceMembeAccount"
    ADD CONSTRAINT "WorkspaceMembeAccount_pkey" PRIMARY KEY (id);


--
-- Name: WorkspaceMember WorkspaceMember_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WorkspaceMember"
    ADD CONSTRAINT "WorkspaceMember_pkey" PRIMARY KEY (id);


--
-- Name: Workspace Workspace_parentWorkspaceId_externalId_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Workspace"
    ADD CONSTRAINT "Workspace_parentWorkspaceId_externalId_key" UNIQUE ("parentWorkspaceId", "externalId");


--
-- Name: Workspace Workspace_parentWorkspaceId_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Workspace"
    ADD CONSTRAINT "Workspace_parentWorkspaceId_name_key" UNIQUE NULLS NOT DISTINCT ("parentWorkspaceId", name);


--
-- Name: Workspace Workspace_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Workspace"
    ADD CONSTRAINT "Workspace_pkey" PRIMARY KEY (id);


--
-- Name: WriteKey WriteKey_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WriteKey"
    ADD CONSTRAINT "WriteKey_pkey" PRIMARY KEY (id);


--
-- Name: AdminApiKey_workspaceId_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "AdminApiKey_workspaceId_name_key" ON public."AdminApiKey" USING btree ("workspaceId", name);


--
-- Name: Broadcast_workspaceId_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Broadcast_workspaceId_name_key" ON public."Broadcast" USING btree ("workspaceId", name);


--
-- Name: ComponentConfiguration_workspaceId_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ComponentConfiguration_workspaceId_name_key" ON public."ComponentConfiguration" USING btree ("workspaceId", name);


--
-- Name: ComputedPropertyPeriod_workspaceId_type_computedPropertyId__idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ComputedPropertyPeriod_workspaceId_type_computedPropertyId__idx" ON public."ComputedPropertyPeriod" USING btree ("workspaceId", type, "computedPropertyId", "to");


--
-- Name: DefaultEmailProvider_workspaceId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "DefaultEmailProvider_workspaceId_key" ON public."DefaultEmailProvider" USING btree ("workspaceId");


--
-- Name: DefaultSmsProvider_workspaceId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "DefaultSmsProvider_workspaceId_key" ON public."DefaultSmsProvider" USING btree ("workspaceId");


--
-- Name: EmailProvider_workspaceId_type_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "EmailProvider_workspaceId_type_key" ON public."EmailProvider" USING btree ("workspaceId", type);


--
-- Name: Feature_workspaceId_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Feature_workspaceId_name_key" ON public."Feature" USING btree ("workspaceId", name);


--
-- Name: Integration_workspaceId_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Integration_workspaceId_name_key" ON public."Integration" USING btree ("workspaceId", name);


--
-- Name: Journey_workspaceId_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Journey_workspaceId_name_key" ON public."Journey" USING btree ("workspaceId", name);


--
-- Name: MessageTemplate_workspaceId_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "MessageTemplate_workspaceId_name_key" ON public."MessageTemplate" USING btree ("workspaceId", name);


--
-- Name: OauthToken_workspaceId_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "OauthToken_workspaceId_name_key" ON public."OauthToken" USING btree ("workspaceId", name);


--
-- Name: Secret_workspaceId_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Secret_workspaceId_name_key" ON public."Secret" USING btree ("workspaceId", name);


--
-- Name: SegmentAssignment_workspaceId_userId_segmentId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "SegmentAssignment_workspaceId_userId_segmentId_key" ON public."SegmentAssignment" USING btree ("workspaceId", "userId", "segmentId");


--
-- Name: SegmentIOConfiguration_workspaceId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "SegmentIOConfiguration_workspaceId_key" ON public."SegmentIOConfiguration" USING btree ("workspaceId");


--
-- Name: Segment_resourceType_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Segment_resourceType_idx" ON public."Segment" USING btree ("resourceType");


--
-- Name: Segment_workspaceId_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Segment_workspaceId_name_key" ON public."Segment" USING btree ("workspaceId", name);


--
-- Name: SmsProvider_workspaceId_type_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "SmsProvider_workspaceId_type_key" ON public."SmsProvider" USING btree ("workspaceId", type);


--
-- Name: SubscriptionGroup_workspaceId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SubscriptionGroup_workspaceId_idx" ON public."SubscriptionGroup" USING btree ("workspaceId");


--
-- Name: SubscriptionGroup_workspaceId_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "SubscriptionGroup_workspaceId_name_key" ON public."SubscriptionGroup" USING btree ("workspaceId", name);


--
-- Name: UserJourneyEvent_journeyId_userId_eventKey_eventKeyName_typ_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UserJourneyEvent_journeyId_userId_eventKey_eventKeyName_typ_key" ON public."UserJourneyEvent" USING btree ("journeyId", "userId", "eventKey", "eventKeyName", type, "journeyStartedAt", "nodeId");


--
-- Name: UserPropertyAssignment_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "UserPropertyAssignment_userId_idx" ON public."UserPropertyAssignment" USING btree ("userId");


--
-- Name: UserPropertyAssignment_workspaceId_userPropertyId_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UserPropertyAssignment_workspaceId_userPropertyId_userId_key" ON public."UserPropertyAssignment" USING btree ("workspaceId", "userPropertyId", "userId");


--
-- Name: UserProperty_workspaceId_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UserProperty_workspaceId_name_key" ON public."UserProperty" USING btree ("workspaceId", name);


--
-- Name: WorkspaceMembeAccount_provider_providerAccountId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "WorkspaceMembeAccount_provider_providerAccountId_key" ON public."WorkspaceMembeAccount" USING btree (provider, "providerAccountId");


--
-- Name: WorkspaceMemberRole_workspaceId_workspaceMemberId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "WorkspaceMemberRole_workspaceId_workspaceMemberId_key" ON public."WorkspaceMemberRole" USING btree ("workspaceId", "workspaceMemberId");


--
-- Name: WorkspaceMember_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "WorkspaceMember_email_key" ON public."WorkspaceMember" USING btree (email);


--
-- Name: WorkspaceRelation_parentWorkspaceId_childWorkspaceId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "WorkspaceRelation_parentWorkspaceId_childWorkspaceId_key" ON public."WorkspaceRelation" USING btree ("parentWorkspaceId", "childWorkspaceId");


--
-- Name: WriteKey_workspaceId_secretId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "WriteKey_workspaceId_secretId_key" ON public."WriteKey" USING btree ("workspaceId", "secretId");


--
-- Name: AdminApiKey AdminApiKey_secretId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AdminApiKey"
    ADD CONSTRAINT "AdminApiKey_secretId_fkey" FOREIGN KEY ("secretId") REFERENCES public."Secret"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AdminApiKey AdminApiKey_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AdminApiKey"
    ADD CONSTRAINT "AdminApiKey_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Broadcast Broadcast_journeyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Broadcast"
    ADD CONSTRAINT "Broadcast_journeyId_fkey" FOREIGN KEY ("journeyId") REFERENCES public."Journey"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Broadcast Broadcast_messageTemplateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Broadcast"
    ADD CONSTRAINT "Broadcast_messageTemplateId_fkey" FOREIGN KEY ("messageTemplateId") REFERENCES public."MessageTemplate"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Broadcast Broadcast_segmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Broadcast"
    ADD CONSTRAINT "Broadcast_segmentId_fkey" FOREIGN KEY ("segmentId") REFERENCES public."Segment"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Broadcast Broadcast_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Broadcast"
    ADD CONSTRAINT "Broadcast_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ComponentConfiguration ComponentConfiguration_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ComponentConfiguration"
    ADD CONSTRAINT "ComponentConfiguration_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ComputedPropertyPeriod ComputedPropertyPeriod_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ComputedPropertyPeriod"
    ADD CONSTRAINT "ComputedPropertyPeriod_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DefaultEmailProvider DefaultEmailProvider_emailProviderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DefaultEmailProvider"
    ADD CONSTRAINT "DefaultEmailProvider_emailProviderId_fkey" FOREIGN KEY ("emailProviderId") REFERENCES public."EmailProvider"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DefaultEmailProvider DefaultEmailProvider_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DefaultEmailProvider"
    ADD CONSTRAINT "DefaultEmailProvider_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DefaultSmsProvider DefaultSmsProvider_smsProviderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DefaultSmsProvider"
    ADD CONSTRAINT "DefaultSmsProvider_smsProviderId_fkey" FOREIGN KEY ("smsProviderId") REFERENCES public."SmsProvider"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DefaultSmsProvider DefaultSmsProvider_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DefaultSmsProvider"
    ADD CONSTRAINT "DefaultSmsProvider_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: EmailProvider EmailProvider_secretId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmailProvider"
    ADD CONSTRAINT "EmailProvider_secretId_fkey" FOREIGN KEY ("secretId") REFERENCES public."Secret"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: EmailProvider EmailProvider_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmailProvider"
    ADD CONSTRAINT "EmailProvider_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: EmailTemplate EmailTemplate_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmailTemplate"
    ADD CONSTRAINT "EmailTemplate_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Feature Feature_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Feature"
    ADD CONSTRAINT "Feature_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Integration Integration_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Integration"
    ADD CONSTRAINT "Integration_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Journey Journey_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Journey"
    ADD CONSTRAINT "Journey_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MessageTemplate MessageTemplate_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MessageTemplate"
    ADD CONSTRAINT "MessageTemplate_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: OauthToken OauthToken_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OauthToken"
    ADD CONSTRAINT "OauthToken_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Secret Secret_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Secret"
    ADD CONSTRAINT "Secret_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SegmentAssignment SegmentAssignment_segmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SegmentAssignment"
    ADD CONSTRAINT "SegmentAssignment_segmentId_fkey" FOREIGN KEY ("segmentId") REFERENCES public."Segment"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SegmentAssignment SegmentAssignment_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SegmentAssignment"
    ADD CONSTRAINT "SegmentAssignment_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SegmentIOConfiguration SegmentIOConfiguration_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SegmentIOConfiguration"
    ADD CONSTRAINT "SegmentIOConfiguration_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Segment Segment_subscriptionGroupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Segment"
    ADD CONSTRAINT "Segment_subscriptionGroupId_fkey" FOREIGN KEY ("subscriptionGroupId") REFERENCES public."SubscriptionGroup"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Segment Segment_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Segment"
    ADD CONSTRAINT "Segment_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SmsProvider SmsProvider_secretId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SmsProvider"
    ADD CONSTRAINT "SmsProvider_secretId_fkey" FOREIGN KEY ("secretId") REFERENCES public."Secret"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SmsProvider SmsProvider_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SmsProvider"
    ADD CONSTRAINT "SmsProvider_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SubscriptionGroup SubscriptionGroup_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SubscriptionGroup"
    ADD CONSTRAINT "SubscriptionGroup_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserPropertyAssignment UserPropertyAssignment_userPropertyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserPropertyAssignment"
    ADD CONSTRAINT "UserPropertyAssignment_userPropertyId_fkey" FOREIGN KEY ("userPropertyId") REFERENCES public."UserProperty"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserPropertyAssignment UserPropertyAssignment_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserPropertyAssignment"
    ADD CONSTRAINT "UserPropertyAssignment_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserProperty UserProperty_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserProperty"
    ADD CONSTRAINT "UserProperty_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WorkspaceMembeAccount WorkspaceMembeAccount_workspaceMemberId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WorkspaceMembeAccount"
    ADD CONSTRAINT "WorkspaceMembeAccount_workspaceMemberId_fkey" FOREIGN KEY ("workspaceMemberId") REFERENCES public."WorkspaceMember"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WorkspaceMemberRole WorkspaceMemberRole_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WorkspaceMemberRole"
    ADD CONSTRAINT "WorkspaceMemberRole_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WorkspaceMemberRole WorkspaceMemberRole_workspaceMemberId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WorkspaceMemberRole"
    ADD CONSTRAINT "WorkspaceMemberRole_workspaceMemberId_fkey" FOREIGN KEY ("workspaceMemberId") REFERENCES public."WorkspaceMember"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WorkspaceMember WorkspaceMember_lastWorkspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WorkspaceMember"
    ADD CONSTRAINT "WorkspaceMember_lastWorkspaceId_fkey" FOREIGN KEY ("lastWorkspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: WorkspaceRelation WorkspaceRelation_childWorkspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WorkspaceRelation"
    ADD CONSTRAINT "WorkspaceRelation_childWorkspaceId_fkey" FOREIGN KEY ("childWorkspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WorkspaceRelation WorkspaceRelation_parentWorkspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WorkspaceRelation"
    ADD CONSTRAINT "WorkspaceRelation_parentWorkspaceId_fkey" FOREIGN KEY ("parentWorkspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WriteKey WriteKey_secretId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WriteKey"
    ADD CONSTRAINT "WriteKey_secretId_fkey" FOREIGN KEY ("secretId") REFERENCES public."Secret"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WriteKey WriteKey_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WriteKey"
    ADD CONSTRAINT "WriteKey_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict Ug1i0FmdY3S9z3a4GO6jiBHd9rigIwZvXQQekX1suWnPTYIX4SaVo9ealmbMdC4

